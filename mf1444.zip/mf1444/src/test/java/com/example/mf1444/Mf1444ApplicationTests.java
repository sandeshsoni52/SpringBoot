package com.example.mf1444;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mf1444ApplicationTests {

	@Test
	void contextLoads() {
	}

}
