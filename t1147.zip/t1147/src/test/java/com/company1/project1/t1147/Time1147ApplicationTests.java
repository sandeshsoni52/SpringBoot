package com.company1.project1.t1147;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Time1147ApplicationTests {

	@Test
	void contextLoads() {
	}

}
