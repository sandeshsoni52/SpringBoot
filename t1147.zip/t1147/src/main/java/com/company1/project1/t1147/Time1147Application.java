package com.company1.project1.t1147;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Time1147Application {

	public static void main(String[] args) {
		SpringApplication.run(Time1147Application.class, args);
	}

}
